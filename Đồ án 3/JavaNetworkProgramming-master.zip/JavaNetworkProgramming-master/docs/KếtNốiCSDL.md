# Các bước tiến hành kết nối CSDL

1.  Nạp trình điều khiển
2.  Tạo thông tin kết nối và đối tượng Connection
3.  Tạo đối tượng Statement để thực thi các lệnh
4.  Xử lý dữ liệu
5.  Đóng kết nối CSDL