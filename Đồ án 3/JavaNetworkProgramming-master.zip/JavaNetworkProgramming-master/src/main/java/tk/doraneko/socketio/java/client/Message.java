package tk.doraneko.socketio.java.client;

/**
 * @author tranphuquy19@gmail.com
 * @since 18/10/2019
 */
public class Message {
    public static final String SEND_TYPE_BROADCAST = "123";
    public static final String SEND_TYPE_GROUPT = "124";
    public static final String SEND_TYPE_PRIVATE = "125";
}
