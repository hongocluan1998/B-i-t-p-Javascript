/**
 * Ứng dụng chính quản lí tất cả classes
 * @author tranphuquy19@gmail.com
 * @since 14/10/2019
 */
package tk.doraneko.app;