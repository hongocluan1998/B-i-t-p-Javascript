package tk.doraneko.udp.sendfile.simple;

/**
 * @author tranphuquy19@gmail.com
 * @since 18/10/2019
 */
public class Client {
}
