/**
 * Ứng dụng chat console <i>Single Client</i> | <i>Reopen - Single Client</i> | <i>Multi Client</i>
 * @author tranphuquy19@gmail.com
 * @since 14/10/2019
 */
package tk.doraneko.tcp.chat.simple;