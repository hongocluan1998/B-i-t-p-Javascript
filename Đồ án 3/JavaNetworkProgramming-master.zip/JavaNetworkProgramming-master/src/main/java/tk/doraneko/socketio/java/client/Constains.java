package tk.doraneko.socketio.java.client;

/**
 * @author tranphuquy19@gmail.com
 * @since 18/10/2019
 */
public class Constains {
    public static final String CHAT_SERVER_URL = "https://doraneko.herokuapp.com/";
}
