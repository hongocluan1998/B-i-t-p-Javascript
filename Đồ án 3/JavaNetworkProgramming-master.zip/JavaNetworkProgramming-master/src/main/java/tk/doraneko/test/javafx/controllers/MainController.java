package tk.doraneko.test.javafx.controllers;

import javafx.fxml.Initializable;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * @author tranphuquy19@gmail.com
 * @since 20/10/2019
 */
public class MainController implements Initializable {
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
