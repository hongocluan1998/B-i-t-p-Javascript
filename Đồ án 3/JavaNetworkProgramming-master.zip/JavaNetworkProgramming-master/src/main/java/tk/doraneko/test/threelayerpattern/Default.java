package tk.doraneko.test.threelayerpattern;

/**
 * @author tranphuquy19@gmail.com
 * @since 16/10/2019
 */
public class Default {
}
