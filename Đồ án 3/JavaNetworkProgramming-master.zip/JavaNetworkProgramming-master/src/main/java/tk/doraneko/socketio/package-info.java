/**
 * Chat realtime đơn giản thông qua socket.io
 * Cài đặt dependencies gradle
 * {@code implementation 'io.socket:socket.io-client:1.0.0'}
 * @author tranphuquy19@gmail.com
 * @since 18/10/2019
 */
package tk.doraneko.socketio;