package tk.doraneko.test;

/**
 * @author tranphuquy19@gmail.com
 * @since 13/10/2019
 */
public class TestGetCurrentWorkingDir {
    public static void main(String[] args) {
        System.out.println(System.getProperty("user.dir"));
    }
}
