# Install project

```
    npm install
```