package tk.doraneko.test.swingtest;

/**
 * @author tranphuquy19@gmail.com
 * @since 17/10/2019
 */
public class MainTest {
    public static void main(String[] args) {
        SqlHelper sqlHelper = new SqlHelper();
        sqlHelper.getTiles();
        sqlHelper.getRows();
    }
}
