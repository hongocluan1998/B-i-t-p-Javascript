/**
 * Ứng dụng console gửi file - Multi Client
 * @author tranphuquy19@gmail.com
 * @since 14/10/2019
 */
package tk.doraneko.tcp.sendfile.simple;